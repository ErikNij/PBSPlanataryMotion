#ifndef LOADDATFILE_H
#define LOADDATFILE_H

#include "Planet.h"

void getData(struct Planet3D *planets[], int numbPlanets, int StartEnd);

#endif